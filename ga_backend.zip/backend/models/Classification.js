const mongoose = require("mongoose");

const classificationSchema = new mongoose.Schema(
    {
        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
            index: true,
        },
        category: {
            type: String,
            enum: ["cardboard", "glass", "metal", "organic", "paper", "plastic"],
            required: true,
        },
        confidence: { type: Number, min: 0, max: 1, required: true },
        fileName: { type: String, maxlength: 255 },
    },
    { timestamps: true }
);

classificationSchema.index({ user: 1, createdAt: -1 });

module.exports = mongoose.model("Classification", classificationSchema);
