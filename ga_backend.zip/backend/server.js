const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const connectDB = require("./config/db");

// Load environment variables
dotenv.config();

const app = express();

// Middleware
const allowedOrigins = process.env.CLIENT_ORIGIN
    ? process.env.CLIENT_ORIGIN.split(",").map((origin) => origin.trim())
    : true;
app.use(cors({ origin: allowedOrigins }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false, limit: "1mb" }));

// Routes
app.use("/api/auth", require("./routes/auth"));
app.use("/api/classifications", require("./routes/classifications"));

// Health check
app.get("/", (req, res) => {
    res.json({ message: "GarbageAnalysis API is running" });
});

app.get("/health", (req, res) => {
    const ready = require("mongoose").connection.readyState === 1;
    res.status(ready ? 200 : 503).json({ status: ready ? "ok" : "starting", database: ready ? "connected" : "disconnected" });
});

app.use((req, res) => res.status(404).json({ message: "Route not found" }));
app.use((error, req, res, next) => {
    if (res.headersSent) return next(error);
    if (error.name === "MulterError") {
        const status = error.code === "LIMIT_FILE_SIZE" ? 413 : 400;
        return res.status(status).json({ message: error.code === "LIMIT_FILE_SIZE" ? "Image exceeds the upload size limit" : error.message });
    }
    if (error.message && error.message.startsWith("Only JPEG")) {
        return res.status(415).json({ message: error.message });
    }
    if (error.type === "entity.too.large") return res.status(413).json({ message: "Request body is too large" });
    console.error(error);
    return res.status(500).json({ message: "Server error" });
});

const start = async () => {
    if (!process.env.JWT_SECRET || process.env.JWT_SECRET === "your_jwt_secret_here") {
        throw new Error("Set a secure JWT_SECRET in the environment before starting the API");
    }
    await connectDB();
    const PORT = process.env.PORT || 5000;
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
};

start().catch((error) => {
    console.error(`Server startup failed: ${error.message}`);
    process.exit(1);
});
